
public class RelationalOperations2 {

	public static void main(String[] args) {
	
		int x = 23;
		int y = 23;
		System.out.println("After assigning x to 23 and ,y to 23.");
			
		System.out.println("x==y: " + (x==y) );
		System.out.println("x<y: " + (x<y) );
		System.out.println("x<=y: " + (x<=y) );
		System.out.println("x>y: " + (x>y) );
		System.out.println("x>=y: " + (x>=y) );
		System.out.println("After re-assigning x to 25 and , y to 12.");
		
		x= 25;
		y=12;
		System.out.println("x==y: " + (x==y) );
		System.out.println("x<y: " + (x<y) );
		System.out.println("x<=y: " + (x<=y) );
		System.out.println("x>y: " + (x>y) );
		System.out.println("x>=y: " + (x>=y) );
		
		x= 123;
		y = 153;
        System.out.println("After re-assigning x to 123 and , y to 153.");
		
		x= 25;
		y=12;
		System.out.println("x==y: " + (x==y) );
		System.out.println("x<y: " + (x<y) );
		System.out.println("x<=y: " + (x<=y) );
		System.out.println("x>y: " + (x>y) );
		System.out.println("x>=y: " + (x>=y) );
		
	}

}
