
public class LogicalOperations1 {

	public static void main(String[] args) {
		boolean p =true;
		boolean negation = !p;
		System.out.println("Logical negation of p being "+ p + " is:" + negation );
		p= false;
		negation =!p;
		System.out.println("Logical negatoin of p being " + p + " is:" + negation);

	}
}


