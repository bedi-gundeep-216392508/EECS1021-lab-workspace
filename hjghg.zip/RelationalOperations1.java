
public class RelationalOperations1 {

	public static void main(String[] args) {
		boolean p = 3<5;// True
		boolean q = 5<3; // False
		System.out.println("3 < 5 is " + p);
		System.out.println("5 < 3 is " + q);
		System.out.println("3==5 is " + (p==q));
     
	}

}
